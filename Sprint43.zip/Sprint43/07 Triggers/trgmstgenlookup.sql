CREATE TRIGGER trgmstgenlookup
    BEFORE INSERT OR UPDATE 
    ON public.mstgenlookup
    FOR EACH ROW
    EXECUTE FUNCTION public.mstgenlookuplog();