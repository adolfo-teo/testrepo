DROP FUNCTION IF EXISTS public.deletepatresultsqa;
CREATE OR REPLACE FUNCTION public.deletepatresultsqa(
	p_mode smallint,
	p_patresultsid integer,
	p_emrpatdtlsorderid integer,
	p_emrpatmastorderid integer,
	p_issubtest smallint,
	p_isprofile smallint,
	p_issingle smallint,
	p_parentemrpatdtlsorderid integer,
	p_profileserviceid integer,
	p_serviceid integer,
	p_scheduleid integer,
	p_scheduledtlsid integer,
	p_servicetypeid integer,
	p_mrno character varying,
	p_history character varying,
	p_virologycolour character varying,
	p_virologypriorityid smallint)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
declare
v_count int;
v_count1 int;
subtest_count int;
v_history character varying;
v_colour character varying;
v_count3 int;
BEGIN 
 -- **************** delete patresultsqa****************
-- =============================================
--Author:  Vignesh Nagarajan
-- Create date: 30/07/20
-- Description: 
-- Modi By:
-- Description:
-- Modified By:Suganya R
-- Modified date: 18-05-2023
-- Description: Added p_history parameter for updating history column in patqa table while unauthorizing
-- =============================================
if(p_mode = 1)
then
	if(p_issubtest = 1)
		then
			delete from patresultsqa where  emrpatdtlsorderid = p_emrpatdtlsorderid ;
			delete from patresults where  emrpatdtlsorderid = p_emrpatdtlsorderid ;
    		select count(*) into v_count from patresultsqa where  profileserviceid = p_profileserviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid;
			if(v_count = 0)
				then
					delete from patresultsqa where  serviceid = p_profileserviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid ;
					delete from patresults where  serviceid = p_profileserviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid ;
			end if;
	elseif(p_issingle = 1)	
	then
		delete from patresultsqa where  emrpatdtlsorderid = p_emrpatdtlsorderid ;
		delete from patresults where  emrpatdtlsorderid = p_emrpatdtlsorderid ;
	end if;
elseif(p_mode = 2)
	then
     	select count(*) into v_count from patresultsqa where profileserviceid = p_serviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid;
	 	if(v_count = 0)then
 			delete from patresultsqa where  serviceid = p_serviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid;
 			delete from patresults where  serviceid = p_serviceid and parentemrpatdtlsorderid = p_parentemrpatdtlsorderid;	 
	 	end if;
		
elseif(p_mode=3) then --Kshama For ORNote
delete  from patresultsqa where scheduleid=p_scheduleid and servicetypeid =p_servicetypeid;
end if;

if(p_mode = 1 or p_mode = 2)then -- cancer registry update in patqa 
	select count(*) into v_count1 from patresultsqa where mrno = p_mrno and iscancerregistry=1;
	if(v_count1 = 0)then
		update patqa set history = 
    	Replace(history::text,'"cancerregistry": 1','"cancerregistry": null')::jsonb where  mrno=p_mrno;	
	end if;
	select count(*) into v_count3 from patqa where mrno = p_mrno;--added for updating virology colour and priorityid
		select history into v_history from patqa where mrno = p_mrno;
		if (v_count3>0)then
			if(v_history is null)then
		 		update patqa set history = p_history::jsonb where mrno = p_mrno;
		 	else
		 		v_colour :=(select (arj ->>'virologycolour') from patqa cross JOIN jsonb_array_elements(history) arj where mrno=p_mrno);
				if v_colour is not null then
					update patqa
					set history = (select
								jsonb_agg(
										case value->>'virologycolour'
										when v_colour ::character varying then value || jsonb_build_object('virologycolour', p_virologycolour,'virologypriorityid', p_virologypriorityid)
										else value
										end
									)
								from jsonb_array_elements(history))
					where mrno=p_mrno;
				else
					update patqa
					set history = (select
										jsonb_agg(
										value || jsonb_build_object('virologycolour',  p_virologycolour,'virologypriorityid', p_virologypriorityid)
											)
									from jsonb_array_elements(history))
					where mrno=p_mrno;
				end if;
			end if;
		end if;--virology colour update in patqa
end if;
 END;
$BODY$;
