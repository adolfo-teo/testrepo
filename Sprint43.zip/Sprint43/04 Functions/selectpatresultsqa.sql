DROP FUNCTION IF EXISTS public.selectpatresultsqa;
CREATE OR REPLACE FUNCTION public.selectpatresultsqa(
	p_id integer,
	p_mrno character varying,
	p_mode integer,
	p_fromdate timestamp without time zone,
	p_todate timestamp without time zone,
	p_rootservcategoryid integer,
	p_servicetypeid integer,
	p_parentemrpatdtlsorderid integer,
	p_invpattestresultid integer,
	p_patdemographicsid integer,
	p_emrpatdtlsorderid integer,
	p_criteria character varying,
	p_criteria1 character varying,
	p_servcategoryid integer,
	p_resultflagids integer[],
	p_genuserid integer,
	ref refcursor,
	p_noofrecords integer DEFAULT 10,
	p_startno integer DEFAULT 0)
    RETURNS refcursor
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_dynamicqry text;
DECLARE v_dynamicqry1 text;
DECLARE v_dynamicqry2 text;

BEGIN 
 -- **************** select patresultsqa****************
-- =============================================
--Author: Vignesh Nagarajan 
-- Create date: 26/04/2019
-- Description: select patient service results and its detailed results
-- Modi By:
-- Description: mode 1 - fetch all results like lab,radiology,other
--              mode 2 - fetch  results from visit history
--              mode 3 - fetch all results based on service
-- Modified By:Arya das
-- Modified date:
-- Description: 
-- Modified By: Vishnu Sasi
-- Modified date:
-- Description:mode 4 to fetch service result data for home screen

-- Modified By: Vishnu Sasi
-- Modified date: 06/11/2020
-- Description:add patdemographicsid as parameter
-- =============================================

if p_mode = 1 
	then 
		if(p_rootservcategoryid != -1) then
			open ref for select 
				(case  when  length(resulttype)>1 then null else resulttype::numeric end)resulttype,
				serviceid , servicename,emrpatdtlsorderid, resultstatus,to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE ,emrpatmastorderid, uom,
				IsAttachment,AttachmentPath, istemplate, IsProfile,IsSubtest,resultflag,
				attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
				CASE
           		WHEN resultremarks is not null and addendum is not null THEN 
		   		concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           		WHEN resultremarks is not null and addendum is null THEN  
		   		concat('Remarks :'||E'\n'||resultremarks) 
           		WHEN resultremarks is null and addendum is not null THEN 
		   		concat('Addendum :'||E'\n'||addendum) 																   
		   		ELSE resultremarks																   
        		END as resultremarks,
				--(case resultflag when 1 then '#6A1B9A' when 2 then '#C62828' else '#000000' end)resultkeycolor,
				--1 and 2 -> abnormal low and High , 3 and 4 -> critical low and High 
				(case resultflag when 1 then '#6A1B9A' when 2 then '#6A1B9A' when 3 then '#C62828' when 4 then '#C62828' else '#000000' end) resultkeycolor,
				(case resultstatus when 1 then null when 0 then null else resultvalue end)resultvalue
				,normalrange,providerid,providername,executedsitename from patresultsqa a where  mrno  = p_mrno and  encountermode in (0,1) and
				displaycategoryid=p_rootservcategoryid   and  date(to_char(date(orderdate),'dd-Mon-yyyy')) between  date(to_char(date(p_fromdate),'dd-Mon-yyyy'))  and date(to_char(date(p_todate),'dd-Mon-yyyy')) and isvalid=1 
				order by a.orderdate desc,emrpatmastorderid,parentemrpatdtlsorderid,displayorderprofile,displayorderservice asc ;
 			return ref ;
	else 
 		open ref for select 
			(case  when  length(resulttype)>1 then null else resulttype::numeric end)resulttype,
			serviceid , servicename,emrpatdtlsorderid, resultstatus,to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,emrpatmastorderid, uom,
			IsAttachment,AttachmentPath, istemplate, IsProfile,IsSubtest,resultflag,
			attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
			servcategoryid,servcategoryname,rootservcategoryid,rootservcategoryname,
			CASE
           		WHEN resultremarks is not null and addendum is not null THEN 
		   		concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           		WHEN resultremarks is not null and addendum is null THEN  
		   		concat('Remarks :'||E'\n'||resultremarks) 
           		WHEN resultremarks is null and addendum is not null THEN 
		   		concat('Addendum :'||E'\n'||addendum) 																   
		   		ELSE resultremarks																   
        		END as resultremarks,
			--(case resultflag when 1 then '#6A1B9A' when 2 then '#C62828' else '#000000' end)resultkeycolor,
			--1 and 2 -> abnormal low and High , 3 and 4 -> critical low and High 
			(case resultflag when 1 then '#6A1B9A' when 2 then '#6A1B9A' when 3 then '#C62828' when 4 then '#C62828' else '#000000' end ) resultkeycolor,
			(case resultstatus when 1 then null when 0 then null else resultvalue end)resultvalue
			,normalrange,providerid,providername,executedsitename from patresultsqa a where  mrno  = p_mrno  and encountermode in (0,1) and
			date(to_char(date(orderdate),'dd-Mon-yyyy')) between  date(to_char(date(p_fromdate),'dd-Mon-yyyy'))  
			and date(to_char(date(p_todate),'dd-Mon-yyyy')) and isvalid=1 
			order by a.orderdate DESC,emrpatmastorderid,parentemrpatdtlsorderid,displayorderprofile,displayorderservice ASC ;
 		return ref ;
	end if;
elsif p_mode = 2 
	then							 
		open ref for select (case  when  length(resulttype)>1 then null else resulttype::numeric end)resulttype,
			serviceid , servicename, emrpatdtlsorderid, resultstatus,to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,
			emrpatmastorderid,uom,IsAttachment,AttachmentPath,istemplate,IsProfile,IsSubtest,
			resultflag,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
			CASE
           		WHEN resultremarks is not null and addendum is not null THEN 
		   		concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           		WHEN resultremarks is not null and addendum is null THEN  
		   		concat('Remarks :'||E'\n'||resultremarks) 
           		WHEN resultremarks is null and addendum is not null THEN 
		   		concat('Addendum :'||E'\n'||addendum) 																   
		   		ELSE resultremarks																   
        		END as resultremarks,				
			--(case resultflag when 1 then '#6A1B9A' when 2 then '#C62828' else '#000000' end)resultkeycolor,
			--1 and 2 -> abnormal low and High , 3 and 4 -> critical low and High 
			(case resultflag when 1 then '#6A1B9A' when 2 then '#6A1B9A' when 3 then '#C62828' when 4 then '#C62828' else '#000000' end ) resultkeycolor,
			(case resultstatus when 1 then null when 0 then null else resultvalue end)resultvalue
			,normalrange,providerid,providername from patresultsqa a where  patencounterid  = p_id and isvalid=1 and displaycategoryid!=5
			order by a.orderdate DESC,emrpatmastorderid,parentemrpatdtlsorderid,displayorderprofile,displayorderservice ASC ;
 		return ref ;
elsif p_mode = 3 
	then							 
		open ref for select (case  when  length(resulttype)>1 then null else resulttype::numeric end)resulttype,
 			serviceid , servicename,emrpatdtlsorderid,  resultstatus,to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,
			emrpatmastorderid,uom,IsAttachment,AttachmentPath,istemplate,IsProfile,IsSubtest,
			resultflag,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
				CASE
           		WHEN resultremarks is not null and addendum is not null THEN 
		   		concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           		WHEN resultremarks is not null and addendum is null THEN  
		   		concat('Remarks :'||E'\n'||resultremarks) 
           		WHEN resultremarks is null and addendum is not null THEN 
		   		concat('Addendum :'||E'\n'||addendum) 																   
		   		ELSE resultremarks																   
        		END as resultremarks,
			--(case resultflag when 1 then '#6A1B9A' when 2 then '#C62828' else '#000000' end)resultkeycolor, 
			--1 and 2 -> abnormal low and High , 3 and 4 -> critical low and High 
			(case resultflag when 1 then '#6A1B9A' when 2 then '#6A1B9A' when 3 then '#C62828' when 4 then '#C62828' else '#000000' end ) resultkeycolor,
			resultvalue,(case resultstatus when 1 then null when 0 then null else resultvalue end)resultvalue,
			-- ,required later
			normalrange,providerid,providername from patresultsqa a where  serviceid = p_id and mrno=p_mrno and  encountermode = 0 and
			date(to_char(date(orderdate),'dd-Mon-yyyy')) between  date(to_char(date(p_fromdate),'dd-Mon-yyyy'))  
			and date(to_char(date(p_todate),'dd-Mon-yyyy'))
			and isvalid=1 order by a.orderdate ,displayorderservice ASC ;																		   												 													 
 		return ref ;
elsif p_mode = 4  -- to fetch service result data for home screen	
	then			
-- 		patresultsid,issingle,emrpatdtlsorderid,emrpatmastorderid,resultstatus,parentemrpatdtlsorderid,
--      operatorid,displayorderservice,profileserviceid,invpattestresultid,mrno,patdemographicsid,
--      ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
--      preview,
		open ref for select serviceid,servicename,uom,
		CASE WHEN sampledate IS NULL 
            THEN to_char(authorizationdate,'dd-Mon-yyyy hh12:mi AM')
            ELSE to_char(sampledate,'dd-Mon-yyyy hh12:mi AM')
    	END AS date,
		CASE
           WHEN resultremarks is not null and addendum is not null THEN 
		   concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           WHEN resultremarks is not null and addendum is null THEN  
		   concat('Remarks :'||E'\n'||resultremarks) 
           WHEN resultremarks is null and addendum is not null THEN 
		   concat('Addendum :'||E'\n'||addendum) 																   
		   ELSE resultremarks																   
        END as resultremarks,																			   
		to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,IsProfile,IsSubtest,
		resulttype,resultvalue,resultflag,
		reviewrequired,reviewstatus,reviewcomments,IsAttachment,AttachmentPath,istemplate,rootservcategoryid,
		servicetypeid,providerempid,
		--0 -> normal , 1,2,5 -->abnormal, 3,4,6 --> critical 																   
		(case resultflag when 0 then '#5d5d5d' when 1 then '#800080' when 2 then '#800080' when 3 then '#FF0000' when 4 then '#FF0000' 
	 	when 5 then '#800080' when 6 then '#FF0000' else '#5d5d5d' end) resultkeycolor,																		   																			   
		normalrange,providerid,providername as enteredbyname,servcategoryid,servcategoryname,
		displayorderprofile,baseserviceid,
		attachedreports,1 as actionentryfrom,
		executedsitename,isfavoriteitem(0::int,serviceid::int,2,p_genuserid,baseserviceid) as isfavorite
		from patresultsqa 
		where  mrno= p_mrno and patdemographicsid = p_patdemographicsid and isvalid=1 
		and servicetypeid = p_servicetypeid
		and COALESCE (sampledate,authorizationdate)  between p_fromdate and p_todate							   	 
 		order by COALESCE (sampledate,authorizationdate) desc,
		displayorderprofile asc ;
		--order by date desc,patresultsid,emrpatdtlsorderid,displayorderservice asc ;
 		return ref ;
elsif(p_mode = 5)
	then						 
		open ref for select serviceid as invmastserviceid,parentemrpatdtlsorderid,2 as dtostate from patresultsqa where parentemrpatdtlsorderid = p_parentemrpatdtlsorderid and isprofile = 1;
		return ref ; 	
elsif(p_mode = 6)
	then						 
		open ref for select attachedreports,patresultsid from patresultsqa where invpattestresultid = p_invpattestresultid ;
		return ref ;		
elsif(p_mode=7)
	then						 
		open ref for select patresultsid,servicename,serviceid,CASE WHEN sampledate IS NULL 
            THEN to_char(authorizationdate,'dd-Mon-yyyy hh12:mi AM')
            ELSE to_char(sampledate,'dd-Mon-yyyy hh12:mi AM')
    	END AS date,to_char(resultentrydate,'dd-Mon-yyyy hh12:mi AM')resultentrydate,resulttype,resultvalue,uom,isprofile,providername,
		(case resultflag when 0 then '#5d5d5d' when 1 then '#800080' when 2 then '#800080' when 3 then '#FF0000' when 4 then '#FF0000' 
	 	when 5 then '#800080' when 6 then '#FF0000' else '#5d5d5d' end) resultkeycolor,resultflag,isattachment,attachmentpath,istemplate,
		normalrange,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,						 		
		CASE
           WHEN resultremarks is not null and addendum is not null THEN 
		   concat('Remarks :'||E'\n'||resultremarks ||E'\n'||'Addendum :'||E'\n'|| addendum)
           WHEN resultremarks is not null and addendum is null THEN  
		   concat('Remarks :'||E'\n'||resultremarks) 
           WHEN resultremarks is null and addendum is not null THEN 
		   concat('Addendum :'||E'\n'||addendum) 																   
		   ELSE resultremarks																   
        END as resultremarks				 
		from patresultsqa where mrno=p_mrno and isvalid=1 
		and rootservcategoryid=p_rootservcategoryid and patdemographicsid=p_patdemographicsid and serviceid=p_id
		and COALESCE (sampledate,authorizationdate)   between p_fromdate and p_todate	
		order by date desc;
		return ref ;			
elsif(p_mode=8)-- other services in homescreen
	then
		open ref for select patresultsid,serviceid,servicename,uom,
		CASE WHEN sampledate IS NULL 
            THEN to_char(authorizationdate,'dd-Mon-yyyy hh12:mi AM')
            ELSE to_char(sampledate,'dd-Mon-yyyy hh12:mi AM')
    	END AS date,																   															   
		to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,IsProfile,IsSubtest,issingle,emrpatdtlsorderid,
		emrpatmastorderid,resulttype, resultstatus,resultvalue,resultflag,resultremarks,parentemrpatdtlsorderid,
		reviewrequired,reviewstatus,reviewcomments,IsAttachment,AttachmentPath,istemplate,rootservcategoryid,
		servicetypeid,providerempid,
		--0 -> normal , 1,2,5 -->abnormal, 3,4,6 --> critical 																   
		(case resultflag when 0 then '#5d5d5d' when 1 then '#800080' when 2 then '#800080' when 3 then '#FF0000' when 4 then '#FF0000' 
	 	when 5 then '#800080' when 6 then '#FF0000' else '#5d5d5d' end) resultkeycolor,
		normalrange,providerid,providername as enteredbyname,displayorderservice,servcategoryid,servcategoryname,operatorid,
		profileserviceid,displayorderprofile,baseserviceid,invpattestresultid,mrno,patdemographicsid,
		attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,
		1 as actionentryfrom,executedsitename,isfavoriteitem(0::int,serviceid::int,2,p_genuserid) as isfavorite
		from patresultsqa where  mrno  = p_mrno and isvalid=1 and patdemographicsid = p_patdemographicsid
		and	(servicetypeid = ANY(string_to_array(p_criteria, E',')::int[]) or rootservcategoryid = ANY(string_to_array(p_criteria1, E',')::int[])) 
		and	COALESCE (sampledate,authorizationdate)  between p_fromdate and p_todate																																								   	 
 		order by date desc,patresultsid,emrpatdtlsorderid,displayorderservice asc ;
 		return ref ;

elsif p_mode = 9  -- to fetch service result data for home screen chart list
	then																			   
		open ref for select patresultsid,serviceid,servicename,uom,
		CASE WHEN sampledate IS NULL 
            THEN to_char(authorizationdate,'dd-Mon-yyyy hh12:mi AM')
            ELSE to_char(sampledate,'dd-Mon-yyyy hh12:mi AM')
    	END AS date,																   															   
		to_char(ORDERDATE,'dd-Mon-yyyy hh12:mi AM')ORDERDATE,IsProfile,IsSubtest,issingle,emrpatdtlsorderid,
		emrpatmastorderid,resulttype, resultstatus,resultvalue,resultflag,resultremarks,parentemrpatdtlsorderid,
		reviewrequired,reviewstatus,reviewcomments,IsAttachment,AttachmentPath,istemplate,rootservcategoryid,
		servicetypeid,providerempid,
		--0 -> normal , 1,2,5 -->abnormal, 3,4,6 --> critical 																   
		(case resultflag when 0 then '#5d5d5d' when 1 then '#800080' when 2 then '#800080' when 3 then '#FF0000' when 4 then '#FF0000' 
	 	when 5 then '#800080' when 6 then '#FF0000' else '#5d5d5d' end) resultkeycolor,
		normalrange,providerid,providername as enteredbyname,displayorderservice,servcategoryid,servcategoryname,operatorid,
		profileserviceid,displayorderprofile,baseserviceid,invpattestresultid,mrno,patdemographicsid,
		attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,radiologistid,1 as actionentryfrom,executedsitename
		from patresultsqa where  mrno  = p_mrno
 		and serviceid = ANY(string_to_array(p_criteria, E',')::int[])								 
		and isvalid=1 and patdemographicsid = p_patdemographicsid
		and	COALESCE (sampledate,authorizationdate)  between p_fromdate and p_todate				
 		order by date desc,patresultsid,emrpatdtlsorderid,displayorderservice asc ;
 		return ref ;

elsif p_mode = 10 then -- to fetch service result data for visit summary, By Kshama

	if(p_rootservcategoryid is not null) then
		v_dynamicqry:=concat(' and rootservcategoryid = '||p_rootservcategoryid);
		
		v_dynamicqry2:=concat(' and rootsercategoryid = '||p_rootservcategoryid);
	end if;
	
	if(p_servcategoryid is not null) then
		v_dynamicqry:=concat(v_dynamicqry,' and servcategoryid = '||p_servcategoryid);
		
		v_dynamicqry2:=concat(v_dynamicqry2,' and sercategoryid = '||p_servcategoryid);		
	end if;
	
	if(p_criteria is not null) then
		v_dynamicqry:=concat(v_dynamicqry,' and (upper(servicename) like upper(CONCAT(''%'','''||p_criteria||''',''%''))) ');
	
		v_dynamicqry2:=concat(v_dynamicqry2,' and (upper(servicename) like upper(CONCAT(''%'','''||p_criteria||''',''%''))) ');
	end if;
	
	if(p_resultflagids is not null) then
		if(1= ANY(p_resultflagids)) then-- Abnormal
			v_dynamicqry1:=concat(' resultflag in(1,2,5) ');
		end if;

		if(2= ANY(p_resultflagids)) then--Critical
			if(v_dynamicqry1!='') then
				v_dynamicqry1:=concat(v_dynamicqry1,' or resultflag in (3,4,6) ');
			else
				v_dynamicqry1:=' resultflag in (3,4,6) ';
			end if;
		end if;

     	if(3= ANY(p_resultflagids)) then--Normal
			if(v_dynamicqry1!='') then
				v_dynamicqry1:=concat(v_dynamicqry1,' or resultflag=0 ');
			else
				v_dynamicqry1:=' resultflag=0 ';
			end if;
		end if;
		
		if(v_dynamicqry1!='') then
			v_dynamicqry:=concat(v_dynamicqry,' AND ( ',v_dynamicqry1,') ');
		end if;
		
	end if;
	
	if(p_fromdate is not null and p_todate is not null) then
		v_dynamicqry:=concat(v_dynamicqry,' and (COALESCE(sampledate,authorizationdate) between '''||p_fromdate||''' and '''||p_todate||''') ');
	
		v_dynamicqry2:=concat(v_dynamicqry2,' and (entrydate between '''||p_fromdate||''' and '''||p_todate||''') ');
	end if;
	
	if(p_criteria1 is not null and p_criteria1!='') then
		v_dynamicqry:=concat(v_dynamicqry,' and emrpatdtlsorderid = ANY(string_to_array('''||p_criteria1||''', E'','')::int[])');
	
		v_dynamicqry2:=concat(v_dynamicqry2,' and emrpatdtlsorderid = ANY(string_to_array('''||p_criteria1||''', E'','')::int[])');
	end if;
	
	open ref for execute 
		'select a.* from ( (select patresultsid,serviceid,servicename,null as billeddate,uom,
		COALESCE(sampledate,authorizationdate) as entrydate,
		(CASE WHEN sampledate IS NULL THEN to_char(authorizationdate,''dd-Mon-yyyy hh12:mi AM'')
		ELSE to_char(sampledate,''dd-Mon-yyyy hh12:mi AM'')	END) AS date,
		CASE
		WHEN resultremarks is not null and addendum is not null THEN 
		concat(''Remarks :''||E''\n''||resultremarks ||E''\n''||''Addendum :''||E''\n''|| addendum)
		WHEN resultremarks is not null and addendum is null THEN  
		concat(''Remarks :''||E''\n''||resultremarks) 
		WHEN resultremarks is null and addendum is not null THEN 
		concat(''Addendum :''||E''\n''||addendum) ELSE resultremarks END as resultremarks,
		to_char(orderdate,''dd-Mon-yyyy hh12:mi AM'') as orderdate,isprofile,issubtest,issingle,emrpatdtlsorderid,
		emrpatmastorderid,resulttype, resultstatus,resultvalue,resultflag,parentemrpatdtlsorderid,
		reviewrequired,reviewstatus,reviewcomments,IsAttachment,AttachmentPath,istemplate,rootservcategoryid,
		servicetypeid,providerempid,																   
		(case resultflag when 0 then ''#5d5d5d'' when 1 then ''#800080'' when 2 then ''#800080'' when 3 then ''#FF0000'' when 4 then ''#FF0000'' 
		when 5 then ''#800080'' when 6 then ''#FF0000'' else ''#5d5d5d'' end) resultkeycolor,																		   																			   
		normalrange,providerid,providername as enteredbyname,displayorderservice,servcategoryid,servcategoryname,operatorid,
		profileserviceid,displayorderprofile,baseserviceid,invpattestresultid,mrno,patdemographicsid,
		attachedreports,ispacsenabled,isimageready,isreportready,
		accessionno,radiologistname,radiologistid,1 as actionentryfrom,
		executedsitename,preview,specimen,1 as isresultexist from patresultsqa 
		where mrno= '''||p_mrno||''' and patdemographicsid = '||p_patdemographicsid||' 
		and isvalid=1 '||concat(v_dynamicqry)||' )
		
		union
		
		(select null as patresultsid,serviceid,servicename,
		to_char(billeddate,''dd-Mon-yyyy hh12:mi AM'') as billeddate,null as uom,
		entrydate,null as date,remarks,to_char(entrydate,''dd-Mon-yyyy hh12:mi AM'') as orderdate,
		isprofile,issubtest,issingle,emrpatdtlsorderid,
		emrpatmastorderid,null as resulttype,null as resultstatus,null as resultvalue,
		null as resultflag,parentemrpatdtlsorderid,
		null as reviewrequired,null as reviewstatus,null as reviewcomments,
		null as IsAttachment,null as AttachmentPath,null as istemplate,
		rootsercategoryid as rootservcategoryid,
		servicetypeid,null as providerempid,null as resultkeycolor,																		   																			   
		null as normalrange,null as providerid,enteredbyname,
		displayorderservice,sercategoryid,sercategoryname,null as operatorid,
		profileserviceid,displayorderprofile,profileserviceid as baseserviceid,null as invpattestresultid,
		mrno,patdemographicsid,null as attachedreports,null as ispacsenabled,null as isimageready,
		null as isreportready,null as accessionno,null as radiologistname,null as radiologistid,1 as actionentryfrom,
		null as executedsitename,null as preview,null as specimen,0 as isresultexist from emrpatdtlsorder 
		where mrno= '''||p_mrno||''' and patdemographicsid = '||p_patdemographicsid||' 
		and isvalid=1 and isbilled=1 and statusid=1 '||concat(v_dynamicqry2)||'  )
		)a order by a.entrydate desc, a.displayorderprofile asc limit '||p_noofrecords||' OFFSET '||p_startno||' ';
	return ref;
	
elsif p_mode = 11 then -- To fetch Latest Glucose result, By ATHUL 
	open ref for 
		select serviceid,servicename,resultvalue,uom,normalrange,
		getdateformat(1,sampledate) AS resultdate from patresultsqa 
		where  mrno  = p_mrno and patdemographicsid = p_patdemographicsid and isvalid=1 
		and serviceid = ANY(string_to_array(p_criteria, E',')::int[])		
		and	sampledate between p_fromdate and p_todate				
		order by sampledate desc limit 1;
		return ref ;

elsif p_mode = 12 then -- To fetch 'OR' note data for 'OR preview'
	open ref for 
		select attachedreports from patresultsqa 
		where  mrno  = p_mrno and isvalid=1 and scheduleid = p_criteria::int;
		return ref ;

end if;	

END;
$BODY$;
