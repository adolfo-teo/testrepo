
CREATE OR REPLACE FUNCTION public.mstgenlookuplog()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
DECLARE 
v_action character varying;
BEGIN
  IF (TG_OP = 'UPDATE') THEN
  if(new.isvalid=2)then 
  v_action:='DELETE';
  else v_action:='UPDATE';
  end if;
  INSERT INTO public.mstgenlookuplog(genlookupid,lookuptype,displayorder,lookupvalue,displaylookuptype,referenceid,referenceidtext,parentreferenceid,parentreferencelookuptype,comments,isvalid,moduleid,userentrymode,
    site,enteredbyid,enteredbyname,enteredbyempid,field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field12,field13,field14,field15,field16,field17,
    machine,entereddate,jsonfield1,langrefid,textfield1,field18,field19,useraction,loggedon)
	
	VALUES (new.genlookupid,new.lookuptype,new.displayorder,new.lookupvalue,new.displaylookuptype,new.referenceid,new.referenceidtext,new.parentreferenceid,new.parentreferencelookuptype,new.comments,new.isvalid,new.moduleid,new.userentrymode,
new.site,new.enteredbyid,new.enteredbyname,new.enteredbyempid,new.field1,new.field2,new.field3,new.field4,new.field5,new.field6,new.field7,new.field8,new.field9,new.field10,new.field11,new.field12,new.field13,new.field14,new.field15,new.field16,new.field17,
new.machine,new.entereddate,new.jsonfield1,new.langrefid,new.textfield1,new.field18,new.field19,TG_OP,now());
RETURN new;

	ELSE IF (TG_OP = 'INSERT') THEN
	
INSERT INTO public.mstgenlookuplog(genlookupid,lookuptype,displayorder,lookupvalue,displaylookuptype,referenceid,referenceidtext,parentreferenceid,parentreferencelookuptype,comments,isvalid,moduleid,userentrymode,
    site,enteredbyid,enteredbyname,enteredbyempid,field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field12,field13,field14,field15,field16,field17,
    machine,entereddate,jsonfield1,langrefid,textfield1,field18,field19,useraction,loggedon)
								
	VALUES (new.genlookupid,new.lookuptype,new.displayorder,new.lookupvalue,new.displaylookuptype,new.referenceid,new.referenceidtext,new.parentreferenceid,new.parentreferencelookuptype,new.comments,new.isvalid,new.moduleid,new.userentrymode,
new.site,new.enteredbyid,new.enteredbyname,new.enteredbyempid,new.field1,new.field2,new.field3,new.field4,new.field5,new.field6,new.field7,new.field8,new.field9,new.field10,new.field11,new.field12,new.field13,new.field14,new.field15,new.field16,new.field17,
new.machine,new.entereddate,new.jsonfield1,new.langrefid,new.textfield1,new.field18,new.field19,TG_OP,now());
								
	  RETURN new;
	END IF;
end if;
END;
$BODY$;
