DROP FUNCTION IF EXISTS public.insertgenlookup;
CREATE OR REPLACE FUNCTION public.insertgenlookup(
	OUT p_refid integer,
	p_genlookupid integer,
	p_lookuptype character varying,
	p_lookupvalue character varying,
	p_isvalid integer,
	p_displayorder integer,
	p_userentrymode integer,
	p_parentreferenceid integer,
	p_field1 character varying,
	p_field2 character varying,
	p_field3 character varying,
	p_field4 character varying,
	p_field5 character varying,
	p_field6 character varying,
	p_field7 character varying,
	p_field8 character varying,
	p_field9 character varying,
	p_field10 character varying,
	p_field11 character varying,
	p_field12 character varying,
	p_field13 character varying,
	p_field14 character varying,
	p_field15 character varying,
	p_comments character varying,
	p_referenceidtext character varying,
	p_displaylookuptype character varying,
	p_field16 character varying,
	p_machine character varying,
	p_enteredbyid integer,
	p_enteredbyname character varying,
	p_enteredbyempid character varying,
	p_entereddate timestamp without time zone,
	p_site jsonb,
	p_jsonfield1 jsonb,
	p_parentreferencelookuptype character varying)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_refid integer;
  TableName text;
	DynamicSQL text;
	var_country character varying;
	var_identdoc character varying;
 	var_notidentdoc character varying;
BEGIN 
 -- **************** insert INTO genlookup****************
-- =============================================
--Author:  
-- Create date: 
-- Description: 
-- Modi By:
-- Description:
-- Modified By: Anu K S
-- Modified date: 29-May-2019
-- Description: Create Table for Appointment (LookType='Department')
-- Modified By: Aiswarya Rani N
-- Modified date: 11-Jan-2021
-- Description:Validation for Specimen repeat(LookType='Specimen')
-- Modified By: Gowtham G
-- Modified date: 05-JUL-2021
-- Description:p_refid should be in interger instead of smallint(Changed from smallint to integer)
-- Modified By: Sruthy Marium Jacob
-- Modified date: 19-05-2022
-- Description: Modified For Renaming genlookup to mstgenlookup
-- ============================================= 
--insert into test1 values (100,p_lookuptype);
--raise exception using message='here';
select  max(coalesce(referenceid,0))+1 into v_refid from mstgenlookup where lookuptype=p_lookuptype ;

if (v_refid IS null)	
then
v_refid:=1;
end if;

if (p_lookuptype!='VitalTemplateAssesmentFactorValues' and p_lookuptype !='VitalTemplateAssesmentFactor' and p_lookuptype !='VitalTemplateAssesmentTotalScore' and p_lookuptype!='ExecutionCategoryMapping' and p_lookuptype!='VitalCategoryItems' and p_lookuptype!='VitalCategory')	
then
-- if (p_lookuptype='ExecutionCategoryMapping')	
-- then				
-- if exists(select *  from mstgenlookup
-- where upper(lookupvalue)=upper(p_lookupvalue) and lookuptype=p_lookuptype
-- and isvalid<>2 and field2=p_field2 and field3=p_field3 and site = p_site)
--   then
--  RAISE Exception unique_violation USING MESSAGE = 'YASASII#BLOCK:'||p_lookupvalue||' is already mapped with '||p_field2;
-- end if;
-- end if;
--else
--if exists(select * from mstgenlookup where trim(upper(lookupvalue))=trim(upper(p_lookupvalue)) and lookuptype=p_lookuptype and isvalid<>2)

if exists(select * from mstgenlookup where trim(upper(lookupvalue))=trim(upper(p_lookupvalue)) and lookuptype=p_lookuptype and 
		  isvalid in(1,0)  and lookuptype<>'LaboratoryResultUnit')
 then
 RAISE Exception unique_violation USING MESSAGE = 'YASASII#BLOCK:Name already exist: ' ||p_lookupvalue;
end if;

end if;	
																	  
if (p_lookuptype='VitalCategory') then --unique exception for VitalCategory
if exists(select * from mstgenlookup where trim(upper(lookupvalue))=trim(upper(p_lookupvalue)) and lookuptype=p_lookuptype and isvalid<>2 and enteredbyid=p_enteredbyid)
 then
 RAISE Exception unique_violation USING MESSAGE = 'YASASII#BLOCK:Name already exist: ' ||p_lookupvalue;
end if;
end if;																	  

if (p_lookuptype='Department') then 
update mstgenlookup set field1=1 where lookuptype='Speciality' and referenceid in (select unnest(string_to_array(p_field15,','))::int);
p_field15:=null;
end if;																							  
																	  
   
if ((p_lookuptype='Country' or p_lookuptype='State' or p_lookuptype='City') and p_field4='1') then
update mstgenlookup set field4=null where lookuptype=p_lookuptype and field4='1'; 
end if;
------------------only for country------------------------------------------------
 	if (p_lookuptype='Country' ) then
		select (value::json->>'country')::varchar,field1,field2 into var_country,var_identdoc,var_notidentdoc from genappsetting  where upper(setting)=upper('DefaultCountryStateCity');
		 if(p_lookupvalue=var_country) then
		 if(var_notidentdoc is not null) then
			 select string_agg( referenceid::varchar,',') into p_field8 from (select referenceid::varchar from mstgenlookup where lookuptype= 'IdentifyingDocs' and isvalid=1
																		and referenceid != var_notidentdoc::int  order by  referenceid asc)gen;
		 else
		 	select string_agg( referenceid::varchar,',') into p_field8 from (select referenceid::varchar from mstgenlookup where lookuptype= 'IdentifyingDocs' and isvalid=1
																		 order by  referenceid asc)gen;
		 end if;																 
			p_field6:=var_identdoc;
		 else
		 select string_agg( referenceid::varchar,',') into p_field8 from (select referenceid::varchar from mstgenlookup where lookuptype= 'IdentifyingDocs' and isvalid=1
																		  and referenceid!=var_identdoc::int
																		  order by  referenceid asc)gen;
																		  
		select string_agg( referenceid::varchar,',') into p_field6 from (select referenceid::varchar from mstgenlookup where lookuptype= 'IdentifyingDocs' and isvalid=1
		 																and field7='1' order by  referenceid desc)gen;																  
		 end if;
	end if;	
--------------------------------------------------------------------------------------	
if (p_lookuptype='Specimen' or p_lookuptype='LaboratoryContainers' or p_lookuptype='ExecutionCategory') then --unique exception for Specimen Master
if exists(select * from mstgenlookup where trim(upper(lookupvalue))=trim(upper(p_lookupvalue)) and lookuptype=p_lookuptype and isvalid<>2 )
 then
 RAISE Exception unique_violation USING MESSAGE = 'YASASII#BLOCK:Name already exist: ' ||p_lookupvalue;
else
select  max(coalesce(referenceid,0))+1 into p_displayorder from mstgenlookup where lookuptype=p_lookuptype ;
end if;
end if;	
---Modified For Validation Based On Result Unit

	   
 

if (p_lookuptype='LaboratoryResultUnit') then 
 
if (select genlookupid from mstgenlookup where trim(upper(lookupvalue))=trim(upper(p_lookupvalue))
		  and field1= p_field1 and isvalid<>2 and lookuptype = 'LaboratoryResultUnit')>0 then	  

 RAISE Exception unique_violation USING MESSAGE = 'YASASII#BLOCK:Name already exist: ' ||p_lookupvalue;
end if;
end if;
--raise exception using message='here';
insert into mstgenlookup(lookuptype,lookupvalue,isvalid,displayorder,field1,field2,field3,field4,
field5,field6,field7,field8,field9,field10,field11,field12,field13,field14,field15,
comments,referenceidtext,displaylookuptype,field16,referenceid,userentrymode,parentreferenceid,
machine,site,entereddate,enteredbyid,enteredbyname,enteredbyempid,jsonfield1,parentreferencelookuptype)
 VALUES 
(p_lookuptype,trim(p_lookupvalue),p_isvalid,p_displayorder,p_field1,p_field2,p_field3,p_field4,
 p_field5,p_field6,p_field7,p_field8,p_field9,p_field10,p_field11,p_field12,p_field13,p_field14,
 p_field15,p_comments,p_referenceidtext, p_displaylookuptype,p_field16,v_refid,p_userentrymode,
 p_parentreferenceid,p_machine,p_site,p_entereddate, p_enteredbyid, p_enteredbyname,
 p_enteredbyempid,p_jsonfield1,p_parentreferencelookuptype) 
 
 returning referenceid into p_refid ;

--SELECT * FROM test1 WHERE id='1000'
---
/* if p_field2 = '1' and upper(p_lookuptype)='DEPARTMENT'  then
  -- TableName:= 'Schedule' || (REPLACE(p_lookupvalue, ' ', '' ));
   TableName:= 'Schedule' || v_refid;
  --DynamicSQL:= 'create table public.'||TableName||' (genuserid integer NOT NULL) ';
  --PatDemographicsId_1 integer,
DynamicSQL:= 'create table public.'||TableName||' (
Id Serial,
ScheduleDate timestamp without time zone,
WeekDay smallint,
ResourceMasterId_1 integer NOT NULL,
ScheduleCount_1 character varying(100),
ScheduleJson_1 jsonb,
HolidaySettingId_1 integer ,
ScheduleSettingDtlsId_1  integer,
IsValid_1 smallint,
ToolTipHoliday_1 character varying(1000),
PRIMARY KEY (Id)) TABLESPACE pg_default;';

							--insert into test1(field,field2) values('Anu',@DynamicSQL);
							--commit;
	  EXECUTE  DynamicSQL;
	  
	  --update mstgenlookup set Field3=TableName where genLookupId=p_genlookupid;
	  
 end if;
*/

 
 END;
$BODY$;
