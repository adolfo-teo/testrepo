DROP FUNCTION IF EXISTS public.insertpatresultsqa;
CREATE OR REPLACE FUNCTION public.insertpatresultsqa(
	OUT p_patresultsid integer,
	p_emrpatmastorderid integer,
	p_emrpatdtlsorderid integer,
	p_serviceid integer,
	p_servicename character varying,
	p_sampledate timestamp without time zone,
	p_resultentrydate timestamp without time zone,
	p_resulttype character varying,
	p_resultvalue character varying,
	p_isattachment integer,
	p_attachmentpath jsonb,
	p_resultflag integer,
	p_normalrange character varying,
	p_criticalrange character varying,
	p_resultremarks character varying,
	p_uom character varying,
	p_operatorid character varying,
	p_addedbyoperatordate timestamp without time zone,
	p_isprofile integer,
	p_issubtest integer,
	p_profileserviceid integer,
	p_servcategoryid integer,
	p_servcategoryname character varying,
	p_displayorderservice integer,
	p_displayorderprofile integer,
	p_categorydisplayorder integer,
	p_patencounterid integer,
	p_encountermode integer,
	p_providerid integer,
	p_providername character varying,
	p_orderedsiteid integer,
	p_orderedsitename character varying,
	p_executedsite integer,
	p_executedsitename character varying,
	p_resultstatus integer,
	p_orderdate timestamp without time zone,
	p_authorizationdate timestamp without time zone,
	p_istemplate integer,
	p_rootservcategoryid integer,
	p_rootservcategoryname character varying,
	p_displaycategoryid integer,
	p_reviewstatus integer,
	p_reviewcomments character varying,
	p_isvalid integer,
	p_mrno character varying,
	p_issingle integer,
	p_parentemrpatdtlsorderid integer,
	p_reviewrequired integer,
	p_baseserviceid integer,
	p_patdemographicsid integer,
	p_providerempid character varying,
	p_servicetypeid smallint,
	p_servicetype character varying,
	p_addendum text,
	p_level smallint,
	p_invpattestresultid integer,
	p_attachedreports jsonb,
	p_ispacsenabled smallint,
	p_isimageready smallint,
	p_isreportready smallint,
	p_accessionno character varying,
	p_radiologistname character varying,
	p_radiologistid character varying,
	p_preview text,
	p_scheduleid integer,
	p_scheduledtlsid integer,
	p_mode smallint,
	p_iscancerregistry smallint,
	p_specimen text,
	p_isrepeattest smallint,
	p_room character varying,
	p_roomid smallint,
	p_roomcategoryid smallint,
	p_history character varying,
	p_isreviewrequestemr smallint,
	p_virologycolour character varying,
	p_virologypriorityid smallint)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
declare
DynamicSql text;
v_count int;
v_count1 int;
v_count2 int;
v_history character varying;
v_colour character varying;
v_count3 int;
BEGIN 
 -- **************** insert INTO patresultsqa****************
-- =============================================
--Author: Vignesh Nagarajan 
-- Create date: 28/07/20 
-- Description: 
-- Modi By:
-- Description:
-- Modified By: Jain Abraham
-- Modified date: 03/08/2022
-- Description: To create a history json structure
-- Modified By: chithra
-- Modified date: 10/11/2022
-- Description: update query in mode 5
-- ============================================= 

if(p_mode=5) then --for OR Note, Kshama
if EXISTS (select  from patresultsqa where serviceid = p_serviceid and scheduleid = p_scheduleid) then
	insert into patresultsqa(emrpatmastorderid,emrpatdtlsorderid,serviceid,servicename,sampledate,
							 resultentrydate,resulttype,resultvalue,isattachment,attachmentpath,
							 resultflag,normalrange,criticalrange,resultremarks,uom,operatorid,addedbyoperatordate,isprofile,issubtest,profileserviceid,servcategoryid,servcategoryname,displayorderservice,displayorderprofile,categorydisplayorder,patencounterid,encountermode,providerid,providername,orderedsiteid,orderedsitename,executedsite,executedsitename,resultstatus,orderdate,authorizationdate,istemplate,rootservcategoryid,rootservcategoryname,displaycategoryid,reviewstatus,reviewcomments,mrno,issingle,parentemrpatdtlsorderid,reviewrequired,baseserviceid,patdemographicsid,providerempid,servicetypeid,servicetype,addendum,level,invpattestresultid,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,
							 radiologistid,preview,scheduleid,scheduledtlsid,room,roomid,roomcategoryid)
	VALUES 
	(p_emrpatmastorderid,p_emrpatdtlsorderid,p_serviceid,p_servicename,
	 p_sampledate,p_resultentrydate,p_resulttype,p_resultvalue,
	 p_isattachment,p_attachmentpath,p_resultflag,p_normalrange,
	 p_criticalrange,p_resultremarks,p_uom,p_operatorid,
	 p_addedbyoperatordate,p_isprofile,p_issubtest,p_profileserviceid,
	 p_servcategoryid,p_servcategoryname,p_displayorderservice,p_displayorderprofile,
	 p_categorydisplayorder,p_patencounterid,p_encountermode,
	 p_providerid,p_providername,p_orderedsiteid,p_orderedsitename,
	 p_executedsite,p_executedsitename,p_resultstatus,p_orderdate,
	 p_authorizationdate,p_istemplate,p_rootservcategoryid,p_rootservcategoryname,
	 p_displaycategoryid,p_reviewstatus,p_reviewcomments,p_mrno,p_issingle,
	 p_parentemrpatdtlsorderid,p_reviewrequired,p_baseserviceid,p_patdemographicsid,
	 p_providerempid,p_servicetypeid,p_servicetype,p_addendum,p_level,p_invpattestresultid,
	 p_attachedreports,p_ispacsenabled,p_isimageready,p_isreportready,p_accessionno,
	 p_radiologistname,p_radiologistid,p_preview,p_scheduleid,p_scheduledtlsid,p_room,p_roomid,p_roomcategoryid) 
	returning patresultsid into p_patresultsid ;
	else
				UPDATE patresultsqa  set attachedreports = p_attachedreports,preview=p_preview,authorizationdate = p_authorizationdate where serviceid =p_serviceid and scheduleid = p_scheduleid;
	 	end if;
else
	if(p_isrepeattest = 0)then
		select count(*) into v_count from patresultsqa where emrpatdtlsorderid = p_emrpatdtlsorderid;
	
	
		if(v_count = 0) then	
			insert into patresultsqa(emrpatmastorderid,emrpatdtlsorderid,serviceid,servicename,sampledate,
			resultentrydate,resulttype,resultvalue,isattachment,attachmentpath,resultflag,normalrange,
			criticalrange,resultremarks,uom,operatorid,addedbyoperatordate,isprofile,issubtest,profileserviceid,
			servcategoryid,servcategoryname,displayorderservice,displayorderprofile,categorydisplayorder,
			patencounterid,encountermode,providerid,providername,orderedsiteid,orderedsitename,executedsite,
			executedsitename,resultstatus,orderdate,authorizationdate,istemplate,rootservcategoryid,
			rootservcategoryname,displaycategoryid,reviewstatus,reviewcomments,mrno,issingle,
			parentemrpatdtlsorderid,reviewrequired,baseserviceid,patdemographicsid,providerempid,servicetypeid,
			servicetype,addendum,level,invpattestresultid,attachedreports,ispacsenabled,isimageready,isreportready,
			accessionno,radiologistname,radiologistid,preview,iscancerregistry,specimen,room,roomid,roomcategoryid,isreviewrequestemr)
			VALUES 
			(p_emrpatmastorderid,p_emrpatdtlsorderid,p_serviceid,p_servicename,p_sampledate,p_resultentrydate,
			 p_resulttype,p_resultvalue,p_isattachment,p_attachmentpath,p_resultflag,p_normalrange,p_criticalrange,
			 p_resultremarks,p_uom,p_operatorid,p_addedbyoperatordate,p_isprofile,p_issubtest,p_profileserviceid,
			 p_servcategoryid,p_servcategoryname,p_displayorderservice,p_displayorderprofile,
			 p_categorydisplayorder,p_patencounterid,p_encountermode,p_providerid,p_providername,p_orderedsiteid,
			 p_orderedsitename,p_executedsite,p_executedsitename,p_resultstatus,p_orderdate,p_authorizationdate,
			 p_istemplate,p_rootservcategoryid,p_rootservcategoryname,p_displaycategoryid,p_reviewstatus,
			 p_reviewcomments,p_mrno,p_issingle,p_parentemrpatdtlsorderid,p_reviewrequired,p_baseserviceid,
			 p_patdemographicsid,p_providerempid,p_servicetypeid,p_servicetype,p_addendum,p_level,
			 p_invpattestresultid,p_attachedreports,p_ispacsenabled,p_isimageready,p_isreportready,
			 p_accessionno,p_radiologistname,p_radiologistid,p_preview,p_iscancerregistry,p_specimen,
			 p_room,p_roomid,p_roomcategoryid,p_isreviewrequestemr)
			 returning patresultsid into p_patresultsid ;
			insert into patresults(patresultsid,emrpatmastorderid,emrpatdtlsorderid,serviceid,servicename,sampledate,resultentrydate,
								   resulttype,resultvalue,isattachment,attachmentpath,resultflag,normalrange,criticalrange,
								   resultremarks,uom,operatorid,addedbyoperatordate,isprofile,issubtest,
								   profileserviceid,servcategoryid,servcategoryname,displayorderservice,
								   displayorderprofile,categorydisplayorder,patencounterid,encountermode,
								   providerid,providername,orderedsiteid,orderedsitename,executedsite,executedsitename,
								   resultstatus,orderdate,authorizationdate,istemplate,rootservcategoryid,rootservcategoryname,
								   displaycategoryid,reviewstatus,reviewcomments,mrno,issingle,parentemrpatdtlsorderid,reviewrequired,
								   baseserviceid,patdemographicsid,providerempid,servicetypeid,servicetype,addendum,
								   level,invpattestresultid,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,
								   radiologistname,radiologistid,preview,iscancerregistry,specimen,isreviewrequestemr)
			VALUES 
			(p_patresultsid,p_emrpatmastorderid,p_emrpatdtlsorderid,p_serviceid,p_servicename,p_sampledate,p_resultentrydate,
			 p_resulttype,p_resultvalue,p_isattachment,p_attachmentpath,p_resultflag,p_normalrange,p_criticalrange,
			 p_resultremarks,p_uom,p_operatorid,p_addedbyoperatordate,p_isprofile,p_issubtest,p_profileserviceid,
			 p_servcategoryid,p_servcategoryname,p_displayorderservice,p_displayorderprofile,p_categorydisplayorder,
			 p_patencounterid,p_encountermode,p_providerid,p_providername,p_orderedsiteid,p_orderedsitename,
			 p_executedsite,p_executedsitename,p_resultstatus,p_orderdate,p_authorizationdate,p_istemplate,
			 p_rootservcategoryid,p_rootservcategoryname,p_displaycategoryid,p_reviewstatus,p_reviewcomments,
			 p_mrno,p_issingle,p_parentemrpatdtlsorderid,p_reviewrequired,p_baseserviceid,p_patdemographicsid,
			 p_providerempid,p_servicetypeid,p_servicetype,p_addendum,p_level,p_invpattestresultid,p_attachedreports,
			 p_ispacsenabled,p_isimageready,p_isreportready,p_accessionno,p_radiologistname,p_radiologistid,p_preview,
			 p_iscancerregistry,p_specimen,p_isreviewrequestemr);
		else
			update patresultsqa set addendum = p_addendum,resultstatus = p_resultstatus,resultvalue = p_resultvalue,
			authorizationdate = p_authorizationdate where emrpatdtlsorderid = p_emrpatdtlsorderid;																				   
			update patresults set addendum = p_addendum,resultstatus = p_resultstatus,resultvalue = p_resultvalue,
			authorizationdate = p_authorizationdate where emrpatdtlsorderid = p_emrpatdtlsorderid;																				   
		end if;
		select count(*) into v_count1 from patresultsqa where mrno = p_mrno and iscancerregistry=1;--CancerRegistry update in Patqa
		select count(*) into v_count3 from patqa where mrno = p_mrno;--added for updating virology colour and priorityid
		select history into v_history from patqa where mrno = p_mrno;
		if (v_count3>0)then
			if(v_history is null)then
		 		update patqa set history = p_history::jsonb where mrno = p_mrno;
		 	else
		 	v_colour :=(select (arj ->>'virologycolour') from patqa cross JOIN jsonb_array_elements(history) arj where mrno=p_mrno);
				if v_colour is not null then
					update patqa
					set history = (select
								jsonb_agg(
										case value->>'virologycolour'
										when v_colour ::character varying then value || jsonb_build_object('virologycolour', p_virologycolour,'virologypriorityid', p_virologypriorityid)
										else value
										end
									)
								from jsonb_array_elements(history))
					where mrno=p_mrno;
				else
					update patqa
					set history = (select
										jsonb_agg(
										value || jsonb_build_object('virologycolour',  p_virologycolour,'virologypriorityid', p_virologypriorityid)
											)
									from jsonb_array_elements(history))
					where mrno=p_mrno;
				end if;
			end if;
		end if;
		--------------added
		if(v_count1 >0 and v_history is null)then
		    update patqa set history = p_history::jsonb where mrno = p_mrno;
		elseif(v_count1 >0 and v_history is not null)then
			update patqa set history = 
    		Replace(history::text,'"cancerregistry": null','"cancerregistry": 1')::jsonb where  mrno=p_mrno;
			 update patqa set history = p_history::jsonb where mrno = p_mrno;
		end if;
		
	end if;

end if;
if(p_mode=6) then --for Service admin, Anandraj
if EXISTS (select  from patresultsqa where mrno != p_mrno or mrno is null ) then
	insert into patresultsqa(emrpatmastorderid,emrpatdtlsorderid,serviceid,servicename,sampledate,
							 resultentrydate,resulttype,resultvalue,isattachment,attachmentpath,
							 resultflag,normalrange,criticalrange,resultremarks,uom,operatorid,addedbyoperatordate,isprofile,issubtest,profileserviceid,servcategoryid,servcategoryname,displayorderservice,displayorderprofile,categorydisplayorder,patencounterid,encountermode,providerid,providername,orderedsiteid,orderedsitename,executedsite,executedsitename,resultstatus,orderdate,authorizationdate,istemplate,rootservcategoryid,rootservcategoryname,displaycategoryid,reviewstatus,reviewcomments,mrno,issingle,parentemrpatdtlsorderid,reviewrequired,baseserviceid,patdemographicsid,providerempid,servicetypeid,servicetype,addendum,level,invpattestresultid,attachedreports,ispacsenabled,isimageready,isreportready,accessionno,radiologistname,
							 radiologistid,preview,scheduleid,scheduledtlsid,room,roomid,roomcategoryid)
	VALUES 
	(p_emrpatmastorderid,p_emrpatdtlsorderid,p_serviceid,p_servicename,
	 p_sampledate,p_resultentrydate,p_resulttype,p_resultvalue,
	 p_isattachment,p_attachmentpath,p_resultflag,p_normalrange,
	 p_criticalrange,p_resultremarks,p_uom,p_operatorid,
	 p_addedbyoperatordate,p_isprofile,p_issubtest,p_profileserviceid,
	 p_servcategoryid,p_servcategoryname,p_displayorderservice,p_displayorderprofile,
	 p_categorydisplayorder,p_patencounterid,p_encountermode,
	 p_providerid,p_providername,p_orderedsiteid,p_orderedsitename,
	 p_executedsite,p_executedsitename,p_resultstatus,p_orderdate,
	 p_authorizationdate,p_istemplate,p_rootservcategoryid,p_rootservcategoryname,
	 p_displaycategoryid,p_reviewstatus,p_reviewcomments,p_mrno,p_issingle,
	 p_parentemrpatdtlsorderid,p_reviewrequired,p_baseserviceid,p_patdemographicsid,
	 p_providerempid,p_servicetypeid,p_servicetype,p_addendum,p_level,p_invpattestresultid,
	 p_attachedreports,p_ispacsenabled,p_isimageready,p_isreportready,p_accessionno,
	 p_radiologistname,p_radiologistid,p_preview,p_scheduleid,p_scheduledtlsid,p_room,p_roomid,p_roomcategoryid) 
	returning patresultsid into p_patresultsid ;
	else
				UPDATE patresultsqa  set attachedreports = p_attachedreports,preview=p_preview,authorizationdate = p_authorizationdate where mrno =p_mrno ;
	 	end if;
end if;
END;
$BODY$;
