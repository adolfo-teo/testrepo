-- FUNCTION: public.updatepatresultsqa(integer, character varying, integer, integer, integer, integer, character varying, timestamp without time zone, timestamp without time zone, character varying, character varying, integer, jsonb, integer, character varying, character varying, character varying, character varying, character varying, timestamp without time zone, integer, integer, integer, integer, character varying, integer, integer, integer, integer, integer, integer, character varying, integer, character varying, integer, character varying, integer, timestamp without time zone, timestamp without time zone, integer, integer, character varying, integer, integer, character varying, integer, character varying, integer, integer, integer, integer, integer, character varying, smallint, character varying, text, smallint, jsonb, character varying, smallint, smallint, smallint, character varying, character varying, character varying, text, smallint, integer, integer, character varying, timestamp without time zone, integer, character varying, character varying)

-- DROP FUNCTION public.updatepatresultsqa(integer, character varying, integer, integer, integer, integer, character varying, timestamp without time zone, timestamp without time zone, character varying, character varying, integer, jsonb, integer, character varying, character varying, character varying, character varying, character varying, timestamp without time zone, integer, integer, integer, integer, character varying, integer, integer, integer, integer, integer, integer, character varying, integer, character varying, integer, character varying, integer, timestamp without time zone, timestamp without time zone, integer, integer, character varying, integer, integer, character varying, integer, character varying, integer, integer, integer, integer, integer, character varying, smallint, character varying, text, smallint, jsonb, character varying, smallint, smallint, smallint, character varying, character varying, character varying, text, smallint, integer, integer, character varying, timestamp without time zone, integer, character varying, character varying);

CREATE OR REPLACE FUNCTION public.updatepatresultsqa(
	p_mode integer,
	p_criteria character varying,
	p_patresultsid integer,
	p_emrpatmastorderid integer,
	p_emrpatdtlsorderid integer,
	p_serviceid integer,
	p_servicename character varying,
	p_sampledate timestamp without time zone,
	p_resultentrydate timestamp without time zone,
	p_resulttype character varying,
	p_resultvalue character varying,
	p_isattachment integer,
	p_attachmentpath jsonb,
	p_resultflag integer,
	p_normalrange character varying,
	p_criticalrange character varying,
	p_resultremarks character varying,
	p_uom character varying,
	p_operatorid character varying,
	p_addedbyoperatordate timestamp without time zone,
	p_isprofile integer,
	p_issubtest integer,
	p_profileserviceid integer,
	p_servcategoryid integer,
	p_servcategoryname character varying,
	p_displayorderservice integer,
	p_displayorderprofile integer,
	p_categorydisplayorder integer,
	p_patencounterid integer,
	p_encountermode integer,
	p_providerid integer,
	p_providername character varying,
	p_orderedsiteid integer,
	p_orderedsitename character varying,
	p_executedsite integer,
	p_executedsitename character varying,
	p_resultstatus integer,
	p_orderdate timestamp without time zone,
	p_authorizationdate timestamp without time zone,
	p_istemplate integer,
	p_rootservcategoryid integer,
	p_rootservcategoryname character varying,
	p_displaycategoryid integer,
	p_reviewstatus integer,
	p_reviewcomments character varying,
	p_isvalid integer,
	p_mrno character varying,
	p_issingle integer,
	p_parentemrpatdtlsorderid integer,
	p_reviewrequired integer,
	p_baseserviceid integer,
	p_patdemographicsid integer,
	p_providerempid character varying,
	p_servicetypeid smallint,
	p_servicetype character varying,
	p_addendum text,
	p_level smallint,
	p_attachedreports jsonb,
	p_mediaids character varying,
	p_ispacsenabled smallint,
	p_isimageready smallint,
	p_isreportready smallint,
	p_accessionno character varying,
	p_radiologistname character varying,
	p_radiologistid character varying,
	p_preview text,
	p_iscancerregistry smallint,
	p_scheduleid integer,
	p_requeststatusid integer,
	p_reviewedcomments character varying,
	p_reviewedon timestamp without time zone,
	p_reviewedbyid integer,
	p_reviewedbyname character varying,
	p_reviewedbyempid character varying)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
declare
attachedreports_count text;
BEGIN
 -- **************** update patresultsqa****************
-- =============================================
-- Author:  Vishnu Sasi
-- Create date: 17/07/2020
-- Description: mode 0 -to update reviewstatus from homescreen
-- Modified By:Vignesh Nagarajan
-- Modified date: 30/07/20
-- Description: mode-1 for result data update
-- Modified By:Anoop D Thomas
-- Modified date:23/09/2020
-- Description: mode-4 for result data update from RIS Inbound
-- Modified By: Sruthy Marium Jacob
-- Modified date:14/10/2022
-- Description: Modified Mode 1 For Updating ResultFlag-Colour Indication[Correction in Emr HomeScreen]
-- Modified By: Josna Thachil
-- Modified date:4//2023
-- Description:Added mode 6 - For updating review request related fields 
-- ============================================= 

if(p_mode = 0) 
	then
		update patresultsqa Rest set reviewstatus=1 from (select  unnest(string_to_array(p_criteria, ','))::INT patresultid) criteria
		where Rest.patresultsid =criteria.patresultid;		
elseif(p_mode = 1) --for result data update
	then																		 
 		update patresultsqa set isattachment=p_isattachment,addendum = p_addendum,resultstatus = p_resultstatus,resultvalue = p_resultvalue,authorizationdate = p_authorizationdate,attachedreports=p_attachedreports,preview=p_preview,resultflag=p_resultflag where emrpatdtlsorderid = p_emrpatdtlsorderid;																				   
 		update patresults set isattachment=p_isattachment,addendum = p_addendum,resultstatus = p_resultstatus,resultvalue = p_resultvalue,authorizationdate = p_authorizationdate,attachedreports=p_attachedreports,preview=p_preview,resultflag=p_resultflag where emrpatdtlsorderid = p_emrpatdtlsorderid;																												
elseif(p_mode=2)
	then																		 
 		update patresultsqa set reviewstatus = 1 where patresultsid = p_patresultsid;	
elseif(p_mode=3)
	then																		 
 		UPDATE patresultsqa  i set attachedreports=(SELECT array_to_json(array_agg(elem)) AS details FROM (select * from patresultsqa where emrpatdtlsorderid = p_emrpatdtlsorderid) i2
        ,jsonb_array_elements(i2.attachedreports) elem WHERE  not EXISTS (select jsonb_array_elements(i2.attachedreports) elem where elem->>'mediafileid' in (select unnest(string_to_array(p_mediaids, '',''))))) 
     	WHERE   i.emrpatdtlsorderid = p_emrpatdtlsorderid;
 		UPDATE patresults  i set attachedreports=(SELECT array_to_json(array_agg(elem)) AS details FROM (select * from patresultsqa where emrpatdtlsorderid = p_emrpatdtlsorderid) i2
        ,jsonb_array_elements(i2.attachedreports) elem WHERE  not EXISTS (select jsonb_array_elements(i2.attachedreports) elem where elem->>'mediafileid' in (select unnest(string_to_array(p_mediaids, '',''))))) 
     	WHERE   i.emrpatdtlsorderid = p_emrpatdtlsorderid;	 
	 
elseif(p_mode=4) -- For RIS Inbound
	then
 		update patresultsqa set isattachment=p_isattachment,addendum = p_addendum,resultstatus = p_resultstatus,reviewstatus = p_reviewstatus,attachedreports = p_attachedreports,authorizationdate = p_authorizationdate,ispacsenabled = p_ispacsenabled,isimageready = p_isimageready,isreportready = p_isreportready,accessionno = p_accessionno,radiologistname = p_radiologistname,radiologistid = p_radiologistid,resulttype = p_resulttype,baseserviceid = p_baseserviceid,sampledate = p_sampledate where emrpatdtlsorderid = p_emrpatdtlsorderid;
 		update patresults set isattachment=p_isattachment,addendum = p_addendum,resultstatus = p_resultstatus,reviewstatus = p_reviewstatus,attachedreports = p_attachedreports,authorizationdate = p_authorizationdate,ispacsenabled = p_ispacsenabled,isimageready = p_isimageready,isreportready = p_isreportready,accessionno = p_accessionno,radiologistname = p_radiologistname,radiologistid = p_radiologistid,resulttype = p_resulttype,baseserviceid = p_baseserviceid,sampledate = p_sampledate where emrpatdtlsorderid = p_emrpatdtlsorderid;

elseif(p_mode=5)
	then																		 
 		UPDATE patresultsqa  set attachedreports = p_attachedreports,preview=p_preview,authorizationdate = p_authorizationdate where serviceid =p_serviceid and scheduleid = p_scheduleid;

elseif(p_mode=6)
	then	
	    UPDATE patresults  set requeststatusid = p_requeststatusid,reviewedcomments=p_reviewedcomments,
		       reviewedon = p_reviewedon,reviewedbyid=p_reviewedbyid,reviewedbyname =p_reviewedbyname,
			   reviewedbyempid=p_reviewedbyempid
		 WHERE emrpatdtlsorderid = p_emrpatdtlsorderid;
		 
 		 UPDATE patresultsqa  set requeststatusid = p_requeststatusid,reviewedcomments=p_reviewedcomments,
		       reviewedon = p_reviewedon,reviewedbyid=p_reviewedbyid,reviewedbyname =p_reviewedbyname,
			   reviewedbyempid=p_reviewedbyempid
		 WHERE emrpatdtlsorderid = p_emrpatdtlsorderid;

end if;
																	
END;
$BODY$;

 
