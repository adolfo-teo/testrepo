

Alter table patresults
add column requesttypeid smallint,
add column requeststatusid smallint,
add column reviewedcomments text,
add column reviewedon timestamp without time zone,
add column reviewedbyid integer,
add column reviewedbyname varchar(320),
add column reviewedbyempid varchar(20),
add column isreviewrequestemr smallint;

---Adolfo------

Alter table patresultsqa 
add column requesttypeid smallint,
add column requeststatusid smallint,
add column reviewedcomments text,
add column reviewedon timestamp without time zone,
add column reviewedbyid integer,
add column reviewedbyname varchar(320),
add column reviewedbyempid varchar(20),
add column isreviewrequestemr smallint;

